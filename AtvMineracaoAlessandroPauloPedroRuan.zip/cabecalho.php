<html>
<head>
    <meta charset="utf-8">
    <title>Mineração</title>
    <link href="css/materialize.css" rel="stylesheet">
    <link href="css/materialize.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<body>

<nav>
    <div class="nav-wrapper">
            <div class="container">
            <a href="index.php" class="brand-logo">S/L</a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a href="formulario.php">Verificar</a></li>
                <li><a href="listar.php">Listar</a></li> </ul>
        </div>
    </div>
</nav>

<div class="container">



